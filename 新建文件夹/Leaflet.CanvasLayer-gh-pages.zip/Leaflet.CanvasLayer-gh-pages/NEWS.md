# 03/22/2014

- changed layer to be included as a normal layers
- fixed problem on drag (requestAnimationFrame leak)
- added zoom animation
